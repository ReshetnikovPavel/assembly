#include <stdio.h>

int x(int a, int b) {
    return a + b;
}

int main (){
    return x(10, 20);
}
